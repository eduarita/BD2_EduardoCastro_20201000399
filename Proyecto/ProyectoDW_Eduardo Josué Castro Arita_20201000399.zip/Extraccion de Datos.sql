--  EXTRACCION DE DATOS
USE AdventureWorks2019;
-- Tienda
SELECT S.BusinessEntityID, S.Name, ST.Name AS Territory
FROM Sales.Store S
INNER JOIN Sales.SalesPerson SP ON  S.SalesPersonID = SP.BusinessEntityID
INNER JOIN Sales.SalesTerritory ST ON SP.TerritoryID = ST.TerritoryID
GROUP BY S.BusinessEntityID, S.Name, ST.Name
ORDER BY S.BusinessEntityID ASC

-- Producto
Select P.ProductID, P.Name As Producto, PC.Name As Categoria
From Production.Product P
INNER JOIN Production.ProductSubcategory PS ON  P.ProductSubcategoryID = PS.ProductSubcategoryID
INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
Order BY P.ProductID ASC

-- Empleado
SELECT HE.BusinessEntityID,CONCAT(PP.FirstName,' ',PP.Lastname) Nombre, HE.Gender, HE.JobTitle
FROM Sales.SalesPerson E 
INNER JOIN HumanResources.Employee HE ON HE.BusinessEntityID = E.BusinessEntityID
INNER JOIN Person.Person PP ON PP.BusinessEntityID = HE.BusinessEntityID
ORDER BY HE.BusinessEntityID ASC

-- Tiempo
SELECT CONVERT(DATE, OrderDate) TiempoID, DATEPART(YEAR, OrderDate) as A�o, DATEPART(QUARTER, OrderDate) As Trimestre, 
DATEPART(MONTH, OrderDate) Mes FROM Sales.SalesOrderHeader
GROUP BY OrderDate
ORDER BY TiempoID ASC

--Cliente
SELECT SC.CustomerID, CONCAT(PP.FirstName,' ',PP.Lastname) Nombre, ST.Name AS Territory
FROM Sales.Customer SC
INNER JOIN Person.Person PP ON SC.PersonID = PP.BusinessEntityID
INNER JOIN Sales.SalesTerritory ST ON SC.TerritoryID = ST.TerritoryID
ORDER BY SC.CustomerID ASC

-- Ventas
SELECT SH.SalesOrderID AS VentaID, S.BusinessEntityID AS TiendaID, SD.ProductID as ProductoID, E.BusinessEntityID AS EmpleadoID, C.CustomerID AS ClienteID, 
CONVERT(DATE,SH.OrderDate) AS TiempoID, SUM(SD.UnitPrice*SD.OrderQty*(1-SD.UnitPriceDiscount)) AS Total
FROM Sales.SalesOrderHeader SH
INNER JOIN Sales.SalesOrderDetail SD ON SH.SalesOrderID = SD.SalesOrderID
INNER JOIN Sales.SalesPerson E ON SH.SalesPersonID = E.BusinessEntityID
INNER JOIN Sales.Customer C ON SH.CustomerID = C.CustomerID
INNER JOIN Sales.Store S ON C.StoreID = S.BusinessEntityID
GROUP BY SH.SalesOrderID, S.BusinessEntityID, SD.ProductID, E.BusinessEntityID, C.CustomerID, SH.OrderDate