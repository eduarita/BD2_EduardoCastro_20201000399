CREATE DATABASE ProyectoDW_AdventureWorks;
GO
USE ProyectoDW_AdventureWorks;
GO
/*Tabla de Dimension Producto*/
CREATE TABLE DimProducto(
    ProductoID int NOT NULL,
    NombreProducto nvarchar(50) NOT NULL,
    Categoria nvarchar(50) NOT NULL,
	CONSTRAINT PK_DimProducto PRIMARY KEY (ProductoID)
)
GO
/*Tabla de Dimension Tienda*/
CREATE TABLE DimTienda(
    TiendaID int NOT NULL,
    NombreTienda nvarchar(50) NOT NULL,
    Ubicacion nvarchar(50) NOT NULL,
	CONSTRAINT PK_DimTienda PRIMARY KEY (TiendaID)
)
GO
/*Tabla de Dimension Empleado*/
CREATE TABLE DimEmpleado (
    EmpleadoID int NOT NULL,
    Nombre nvarchar(150) NOT NULL,
    Genero nvarchar(1) NOT NULL,
    Puesto nvarchar(50) NOT NULL,
	CONSTRAINT PK_DimEmpleado PRIMARY KEY (EmpleadoID)
)
GO
/*Tabla de Dimension Tiempo*/
CREATE TABLE DimTiempo (
    TiempoID date NOT NULL,
    Trimestre int NOT NULL,
    Mes int NOT NULL,
    A�o int NOT NULL,
	CONSTRAINT PK_DimTiempo PRIMARY KEY (TiempoID)
)
GO
/*Tabla de Dimension Cliente*/
CREATE TABLE DimCliente (
    ClienteID int NOT NULL,
    Nombre nvarchar(150) NOT NULL,
    Ubicacion nvarchar(50) NOT NULL,
	CONSTRAINT PK_DimCliente PRIMARY KEY (ClienteID)
)
GO
/*Tabla de Hechos Ventas*/
CREATE TABLE Hechos_Ventas(
	CodigoID int IDENTITY(1,1) NOT NULL,
    VentaID int NOT NULL,
    TiendaID int NOT NULL, 
    ProductoID int NOT NULL,
    EmpleadoID int NOT NULL,
    ClienteID int NOT NULL,
    TiempoID date NOT NULL,
    Total DECIMAL(19,4) NOT NULL,
	CONSTRAINT PK_Hechos_Ventas PRIMARY KEY (CodigoID)
)
GO
ALTER TABLE Hechos_Ventas ADD CONSTRAINT FK_TiendaID FOREIGN KEY (TiendaID) REFERENCES DimTienda(TiendaID);
GO
ALTER TABLE Hechos_Ventas ADD CONSTRAINT FK_ProductoID FOREIGN KEY (ProductoID) REFERENCES DimProducto(ProductoID);
GO
ALTER TABLE Hechos_Ventas ADD CONSTRAINT FK_EmpleadoID FOREIGN KEY (EmpleadoID) REFERENCES DimEmpleado(EmpleadoID);
GO
ALTER TABLE Hechos_Ventas ADD CONSTRAINT FK_ClienteID FOREIGN KEY (ClienteID) REFERENCES DimCliente(ClienteID);
GO
ALTER TABLE Hechos_Ventas ADD CONSTRAINT FK_TiempoID FOREIGN KEY (TiempoID) REFERENCES DimTiempo(TiempoID);

/*
SELECT * FROM DimCliente;
SELECT * FROM DimEmpleado;
SELECT * FROM DimProducto;
SELECT * FROM DimTiempo;
SELECT * FROM DimTienda;
SELECT * FROM Hechos_Ventas;
*/